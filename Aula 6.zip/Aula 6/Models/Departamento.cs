namespace IPdotnet.Models.Departamento{
    public class Departamento{

    }
}